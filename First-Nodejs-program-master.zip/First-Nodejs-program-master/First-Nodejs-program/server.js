console.log("this is my server");
//imoport express
const express = require("express");
//create an instance 
const app =  express();
//Define a port
const port = 3000;
//define routes
app.get("/",(req,res)=>{
    console.log(0.1+0.2);
    res.json(0.1+0.2);
});
//listen to the port
app.listen(port,() =>{
    console.log(`server started in port${port}`);
});
