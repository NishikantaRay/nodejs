const port =3000;

//add middleware
app.use(morgan("dev"));

//define rou
//define routes
app.get("/",(req,res)=>{
    console.log(0.1+0.2);
    res.json(0.1+0.2);
});
//listen to the port
app.listen(port,() =>{
    console.log(`server started in port${port}`);
});